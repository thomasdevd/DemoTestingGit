
public class CanMainHaveTwoStaticMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Mian method");

	}
	public static void main1(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("MianOne method");
	}

}
