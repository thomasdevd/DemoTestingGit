
public class TestingCodewar {
	public TestingCodewar() {

	}

	public void newEntry(String key, String value) {
		System.out.println("A fruit that grows on trees");

	}

	public static void main(String[] args) {
	

	TestingCodewar test = new TestingCodewar();
	test.newEntry("Apple", "A fruit that grows on trees");
	
	}	

}